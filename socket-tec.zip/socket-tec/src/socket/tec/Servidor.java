package socket.tec;
import java.io.*;
import java.net.*;
public class Servidor {
    public static void main(String args[]) {
        ServerSocket mi_servicio = null;
        String linea_recibida;
        DataInputStream entrada;
        PrintStream salida;
        Socket socket_conectado = null;
        try {
            mi_servicio = new ServerSocket(2019);
            System.out.println("Servidor Iniciado...");
        }
        catch (IOException excepcion) {
            System.out.println(excepcion);
        }
        try {
            socket_conectado = mi_servicio.accept();
            entrada = new DataInputStream(socket_conectado.getInputStream());
            salida = new PrintStream(socket_conectado.getOutputStream());
            linea_recibida = entrada.readLine();
            String[] aux = linea_recibida.split(",");
            double resultado = 0;
            switch(Integer.parseInt(aux[0])){
                case 1:{
                    System.out.println("Realizar Suma");
                    resultado = Double.parseDouble(aux[1]) + Double.parseDouble(aux[2]);
                }break;
                case 2:{
                    System.out.println("Realizar Resta");
                    resultado = Double.parseDouble(aux[1]) - Double.parseDouble(aux[2]);
                }break;
                case 3:{
                    System.out.println("Realizar Multiplicación");
                    resultado = Double.parseDouble(aux[1]) * Double.parseDouble(aux[2]);
                }break;
                case 4:{
                    System.out.println("Realizar División");
                    resultado = Double.parseDouble(aux[1]) / Double.parseDouble(aux[2]);
                }break;
            }
            salida.println("El resultado es: " + String.format("%.2f", resultado));
            salida.close();
            entrada.close();
            socket_conectado.close();
        }
        catch (IOException excepcion) {
            System.out.println(excepcion);
        }
    }
}